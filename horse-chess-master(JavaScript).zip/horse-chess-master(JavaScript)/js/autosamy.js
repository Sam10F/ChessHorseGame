var Total_secs;
var Total_mins;
var cronometer;

var CheckCell_Required;

var Moves_Required;
var Moves;
var Bonus;

var Level = 1;
var Next_Level = false;
var LevelMoves;

var board = new Array(8);

var cellSelected_x;
var cellSelected_y;

function autosamy(){

	setLevel_Parameters();
	
	for(i = 0; i<8;i++) board[i] = new Array(8);

	ResetTime();
	ClearBoard();

	StarTime();

	/*numero aleatorio de 0 a 7*/
	x = Math.round(Math.random()*7);
	y = Math.round(Math.random()*7);


	cellSelected_x = x;
	cellSelected_y = y;
	SelectCell(x, y);


}

function set_LevelMoves(){
	if(Level == 1) LevelMoves = 64;
	if(Level == 2) LevelMoves = 64;
	if(Level == 3) LevelMoves = 64;
	if(Level == 4) LevelMoves = 64;
	if(Level == 5) LevelMoves = 64;
	if(Level == 6) LevelMoves = 64;
}

function set_Moves_Required(){
	if(Level == 1) LevelMoves = 8;
	if(Level == 2) LevelMoves = 10;
	if(Level == 3) LevelMoves = 12;
	if(Level == 4) LevelMoves = 10;
	if(Level == 5) LevelMoves = 10;
	if(Level == 6) LevelMoves = 1299;
}

function setLevel_Parameters(){

	if(Next_Level){
		Level++;
	}

	LevelMoves = 64;
	Moves = 64;
	Moves_Required = 8;
	Bonus = 0;
}

function SelectCell(x, y){

	Moves--;
	document.getElementById("moves").innerHTML = Moves;

	PaintCell(cellSelected_x, cellSelected_y, "orange");
	PaintHorseCell(x, y, "green");

	if(board[x][y] == 2){
		Bonus++;
		document.getElementById("options").innerHTML =Options + "+" + Bonus;
	}

	board[x][y] = 1;
	cellSelected_x = x;
	cellSelected_y = y;

	CheckCell_Required = true;
	Check_SuccesfulEnd();
	Check_GameOver(x, y);
	Check_newBonus();
}

function Check_newBonus(){
	if((64-Moves) % Moves_Required == 0){
		//Buscar una casilla al azar para poner el bonus
		Bonus_Cell = false;
		while(Bonus_Cell == false){

			Bonus_Cell_x = Math.round(Math.random() * 7);
			Bonus_Cell_y = Math.round(Math.random() * 7);

			if(board[Bonus_Cell_x][Bonus_Cell_y] == 0) Bonus_Cell = true;
		}

		board[Bonus_Cell_x][Bonus_Cell_y] = 2;
		PaintBonusCell(Bonus_Cell_x, Bonus_Cell_y);

	}
}

function PaintBonusCell(x, y){
	cell = document.getElementById("c"+x+y);
	cell.innerHTML="<img src = 'bonus.png'> </img>"
}

function Check_GameOver(x, y){
	Options = 0;

	Check_Move(x, y, 1, 2);		//check move right - top long
	Check_Move(x, y, 2, 1);		//check move right long - top
	Check_Move(x, y, 1, -2);	//check move right - bottom long
	Check_Move(x, y, 2, -1);	//check move right long - bottom
	Check_Move(x, y, -1, 2);	//check move left - top long
	Check_Move(x, y, -2, 1);	//check move left long - top
	Check_Move(x, y, -1, -2);	//check move left - bottom long
	Check_Move(x, y, -2, -1);	//check move left long - bottom

	document.getElementById("options").innerHTML = Options + "+" + Bonus;
	if(!Options){
		if(Bonus) CheckCell_Required = false;
		else ShowMessage("Game Over!", true);	
	} 
}

function Check_Move(x, y, mov_x, mov_y){
		option_x = x+mov_x;
		option_y = y+mov_y;

		if (option_x < 8 && option_y < 8 && 
			option_x >= 0 && option_y >= 0){

			if (board[option_x][option_y] == 0 || board[option_x][option_y] == 2){
				 Options++;	
			}

		}
}

function Check_SuccesfulEnd(){
	SuccesfulEnd = true;
	if(Moves>0) SuccesfulEnd = false;
	if(SuccesfulEnd) ShowMessage("Partida Ganada!", false);
}

function PaintCell(x, y, color){
	cell = document.getElementById("c"+x+y);
	cell.style.background = color;
}

function PaintHorseCell(x, y, color){
	cell = document.getElementById("c"+x+y);
	cell.style.background = color;
	cell.innerHTML="<img src = 'horse.gif'> </img>"
}

function StarTime(){
    secs =0;
    mins =0;
    s = document.getElementById("seconds");
    m = document.getElementById("minutes");

    cronometer = setInterval(
        function(){
            if(secs==60){
                secs=0;
                mins++;
                if (mins<10) m.innerHTML ="0"+mins;
                else m.innerHTML = mins;

                if(mins==60) mins=0;
            }
            if (secs<10) s.innerHTML ="0"+secs;
            else s.innerHTML = secs;

            secs++;
        }
        ,1000);
}

function CheckCell(x, y){
	CheckTrue = true;
	if(CheckCell_Required){
		CheckTrue = false;

		dif_x = x - cellSelected_x;
		dif_y = y - cellSelected_y;

		if (dif_x == 1 && dif_y == 2)   CheckTrue = true; // right - top long
		if (dif_x == 1 && dif_y == -2)  CheckTrue = true; // right - bottom long
		if (dif_x == 2 && dif_y == 1)   CheckTrue = true; // right long - top
		if (dif_x == 2 && dif_y == -1)  CheckTrue = true; // rightlong - bottom
		if (dif_x == -1 && dif_y == 2)  CheckTrue = true; // left - top long
		if (dif_x == -1 && dif_y == -2) CheckTrue = true; // left - bottom long
		if (dif_x == -2 && dif_y == 1)  CheckTrue = true; // left long - top
		if (dif_x == -2 && dif_y == -1) CheckTrue = true; // left long - bottom
	}else{
		if(board[x][y] == 0 || board[x][y] == 2){
			Bonus--;
			document.getElementById("options").innerHTML = Options + "+" + Bonus;
		}
	}

	if(board[x][y] == 1) CheckTrue = false;
	if(CheckTrue) SelectCell(x, y);
}

function ResetTime(){
	clearInterval(cronometer);
}

function ClearBoard(){
	for(i = 0; i<8; i++){
		for(j = 0; j<8; j++){
			board[i][j] = 0;
		}
	}
}

function ShowMessage(string_notificacion, game_over){

	Next_Level = !game_over;
	string_score = "";

	if(game_over == false){
		string_score == "Level -" + Level + "Time 0";
		if(Total_mins < 10) string_score += "0";
		string_score = string_score + Total_mins + ":";
		if(Total_secs < 10) string_score += "0";
		string_score = string_score + Total_secs + ":";
	}else{
		string_score = "Score: " + (LevelMoves - Moves) + "/" + LevelMoves;
	}

	Message = document.getElementById("message");
	Message.style.display = "block";

	Message_Notification = document.getElementById("notification");
	Message_Notification.innerHTML = string_notificacion;

	Message_Message = document.getElementById("final_score");
	Message_Message.innerHTML = string_score;

	Message_Message = document.getElementById("final_time");

	Message_Message.innerHTML ="Tiempo: " + mins + ":" + secs;

}

autosamy();